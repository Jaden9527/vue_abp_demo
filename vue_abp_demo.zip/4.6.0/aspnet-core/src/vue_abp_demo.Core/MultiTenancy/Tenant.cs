﻿using Abp.MultiTenancy;
using vue_abp_demo.Authorization.Users;

namespace vue_abp_demo.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
