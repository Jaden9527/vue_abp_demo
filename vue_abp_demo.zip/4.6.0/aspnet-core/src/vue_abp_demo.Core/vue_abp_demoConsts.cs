﻿namespace vue_abp_demo
{
    public class vue_abp_demoConsts
    {
        public const string LocalizationSourceName = "vue_abp_demo";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
