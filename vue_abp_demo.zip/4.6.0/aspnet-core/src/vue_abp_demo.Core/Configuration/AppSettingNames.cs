﻿namespace vue_abp_demo.Configuration
{
    public static class AppSettingNames
    {
        public const string UiTheme = "App.UiTheme";
    }
}
